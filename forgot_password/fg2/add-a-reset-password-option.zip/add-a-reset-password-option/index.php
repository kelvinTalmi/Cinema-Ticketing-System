<form method="POST" action="send-recovery-mail.php">
	<input type="email" name="email">
	<input type="submit" value="Send recovery email">
</form>